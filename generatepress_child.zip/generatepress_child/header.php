<?php
/**
 * The template for displaying the header.
 *
 * @package GeneratePress
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <?php wp_head(); ?>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
	<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
	<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.min.js"></script>
	<link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
    <script>
    var ajaxurl = "<?php echo admin_url('admin-ajax.php'); ?>";
    </script>
</head>

<body <?php body_class(); ?> <?php generate_do_microdata( 'body' ); ?>>
	<?php do_action( 'wp_body_open' ); ?>

	<header id="masthead" class="site-header custom-header" role="banner">
		<div class="container custom-container">
			<!-- Left div for new logo -->
<div class="site-logo custom-logo">
    <a href="<?php echo esc_url( home_url( '/' ) ); ?>">
        <img src="http://einkaufswolke.de/wp-content/uploads/2023/05/1.svg" alt="Logo" class="custom-logo-image">
    </a>
</div>



			<!-- Middle div for search form -->
<div class="site-search custom-search">
    <form role="search" method="get" id="searchform" action="<?php echo esc_url( home_url( '/' ) ); ?>">
        <input type="text" value="<?php echo get_search_query(); ?>" name="s" id="s" placeholder="Jetzt in 4.450 Shops suchen">
        <button type="submit" id="searchsubmit" style="background: none; border: none;"><i class="header-lupe-icon fas fa-search"></i></button>
    </form>

    <div id="search-results"></div> <!-- Das ist das DIV für das Dropdown-Feld -->
</div>


<div class="site-icons custom-icons">
    <a href="mailto:your-email@example.com" class="custom-icon custom-mail-icon">
        <img src="https://lastenfahrrad-24.de/wp-content/uploads/2023/05/envelope-regular.svg" alt="Envelope Icon">
    </a>
    <a href="#" class="custom-icon custom-heart-icon">
        <img src="https://lastenfahrrad-24.de/wp-content/uploads/2023/05/heart-regular.svg" alt="Heart Icon">
    </a>
    <a href="your-login-link" class="custom-icon custom-user-icon">
        <img src="https://lastenfahrrad-24.de/wp-content/uploads/2023/05/circle-user-regular.svg" alt="User Icon">
    </a>
</div>
		</div>
	</header>
	
		
<div class="horizontal-nav">
    <div class="nav-content">
        <nav class="main-navigation">
        <?php
        wp_nav_menu( array(
            'theme_location' => 'primary',   // Der Name des Menüs, den Sie im WordPress Admin-Bereich erstellt haben
            'menu_id'        => 'primary-menu',
        ) );
        ?>
        </nav>
    </div>
</div>

<header class="mobile-header" role="banner">
    <div class="mobile-header-container">
        <div class="menu-logo-heart">
            <div class="hamburger-container"> <!-- Neues umschließendes div für den Hamburger-Button -->
                <button class="hamburger-menu" type="button">
                    <span class="hamburger-icon"></span>
                </button>
            </div>
           <div class="site-logo custom-logo">
    <a href="<?php echo esc_url( home_url( '/' ) ); ?>">
        <img src="http://einkaufswolke.de/wp-content/uploads/2023/05/1.svg" alt="Logo" class="custom-logo-image">
    </a>
</div>

            <div class="site-icons custom-icons">
                <a href="#" class="custom-icon custom-heart-icon">
                    <img src="https://lastenfahrrad-24.de/wp-content/uploads/2023/05/heart-regular.svg" alt="Heart Icon">
                </a>
            </div>
        </div>
    </div>

    <!-- Search Form -->
    <div class="site-search custom-search">
        <form role="search" method="get" id="searchform" action="<?php echo esc_url( home_url( '/' ) ); ?>">
            <input type="text" value="<?php echo get_search_query(); ?>" name="s" id="s" placeholder="Jetzt in 4.450 Shops suchen">
            <button type="submit" id="searchsubmit" style="background: none; border: none;"><i class="fas fa-search"></i></button>
        </form>
    </div>

<nav class="mobile-navigation swipeout-left-animation">
            <button class="close-menu">&times;</button>
            <?php
            wp_nav_menu( array(
                'theme_location' => 'primary',
                'menu_id'        => 'mobile-menu',
            ) );
            ?>
        </nav>

        <div class="mobile-overlay"></div> <!-- Overlay-Schicht für den abgedunkelten Hintergrund -->
</header>




	<?php do_action( 'generate_after_header' ); ?>

	<div <?php generate_do_attr( 'page' ); ?>>
		<?php
		do_action( 'generate_inside_site_container' );
		?>
		<div <?php generate_do_attr( 'site-content' ); ?>>
			<?php
			do_action( 'generate_inside_container' ); 
			?>
		</div>
	</div>
	
		<?php
	do_action( 'generate_after_header' );
	?>

	<div <?php generate_do_attr( 'page' ); ?>>
		<?php
		do_action( 'generate_inside_site_container' );
		?>
		<div <?php generate_do_attr( 'site-content' ); ?>>
			<?php
			do_action( 'generate_inside_container' ); 
?>

<script>
$(document).ready(function() {
    $("#s").autocomplete({
        source: function(request, response) {
            $.ajax({
                url: "<?php echo admin_url('admin-ajax.php'); ?>",
                type: 'POST',
                data: {
                    action: 'search_with_atlas_search', // Aktualisierte Action
                    term: request.term
                },
                success: function(data) {
                    var results = JSON.parse(data);

                    // Anzeige der Antwort in der Konsole
                    console.log(results);

                    response(results);

                    // Ergebnisse ins Dropdown-Feld einfügen
                    var dropdown = $("#search-results");
                    dropdown.empty(); // Leert das Dropdown-Feld

                    // Fügt die Ergebnisse in das Dropdown-Feld ein
                    for (var i = 0; i < results.length; i++) {
                        var result = results[i];
                        dropdown.append("<div>" + result + "</div>");
                    }
                }
            });
        },
        minLength: 2,
        select: function(event, ui) {
            // Aktion beim Auswählen eines Suchergebnisses
            // Hier können Sie die gewünschte Aktion ausführen, z.B. eine Weiterleitung zur ausgewählten Seite
        }
    });

    $('.close-menu').click(function(event) {
        event.stopPropagation();
        var mobileNav = $('.mobile-navigation');
        mobileNav.removeClass('show');
        mobileNav.addClass('hide'); // Klasse "hide" hinzufügen
    });
});


jQuery(document).ready(function($) {
    var hamburgerButton = $('.hamburger-menu');
    var mobileNav = $('.mobile-navigation');
    var closeButton = $('.close-menu');

    hamburgerButton.click(function(event) {
        event.stopPropagation();
        mobileNav.addClass('show');
        mobileNav.removeClass('hide'); // Klasse "hide" entfernen
    });

    $(document).on('click', '.close-menu', function(event) {
        event.stopPropagation();
        mobileNav.removeClass('show');
        mobileNav.addClass('hide'); // Klasse "hide" hinzufügen
    });

    $(document).on('click', function(event) {
        if (!$(event.target).closest('.mobile-header').length && mobileNav.hasClass('show')) {
            mobileNav.removeClass('show');
            mobileNav.addClass('hide'); // Klasse "hide" hinzufügen
        }
    });
});
	
jQuery(document).ready(function($) {
  var mobileNav = $('.mobile-navigation');

  $('.hamburger-menu').click(function(event) {
    event.stopPropagation();
    mobileNav.addClass('show');
    $('body').css('overflow', 'hidden'); // Scrollen deaktivieren
  });

  $('.close-menu').click(function(event) {
    event.stopPropagation();
    mobileNav.removeClass('show');
    $('body').css('overflow', 'auto'); // Scrollen aktivieren
  });

  $(document).on('click', function(event) {
    if (!$(event.target).closest('.mobile-header').length && mobileNav.hasClass('show')) {
      mobileNav.removeClass('show');
      $('body').css('overflow', 'auto'); // Scrollen aktivieren
    }
  });
});
	
	

</script>