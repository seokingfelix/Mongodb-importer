<?php
/**
 * Functions.php file of your theme.
 */

// Add the custom navigation function
if (!function_exists('custom_generate_add_navigation_after_header')) {
    add_action('generate_after_header', 'custom_generate_add_navigation_after_header', 1);
    /**
     * Generate the navigation based on settings
     *
     * It would be better to have all of these inside one action, but these
     * are kept this way to maintain backward compatibility for people
     * un-hooking and moving the navigation/changing the priority.
     *
     * @since 0.1
     */
    function custom_generate_add_navigation_after_header()
    {
        // Check if the navigation has already been output
        $navigation_output = get_option('custom_navigation_output', false);

        if (!$navigation_output) {
            generate_navigation_position();

            // Set the option to true to indicate that the navigation has been output
            update_option('custom_navigation_output', true);
        }
    }
}

function search_with_atlas_search() {
    // Die Funktion wurde vorübergehend deaktiviert
    /*
    if (isset($_POST['term'])) {
        $searchTerm = $_POST['term'];

        // Verbinden Sie sich mit Ihrer MongoDB Atlas-Datenbank
        $mongoClient = new MongoDB\Client('mongodb+srv://zinkbusiness:hansuwe@Cluster1.bcc8n.mongodb.net/Shopniversum?retryWrites=true&w=majority', [
            'username' => 'zinkbusiness',
            'password' => 'hansuwe',
        ]);

        // Wählen Sie die Datenbank und die Sammlung für Ihre Suche aus
        $database = $mongoClient->selectDatabase('Shopniversum');
        $collection = $database->selectCollection('Shopniversum-datafeeds');

        // Führen Sie die Atlas Search-Abfrage aus und begrenzen Sie die Anzahl der Ergebnisse auf 10
        $results = $collection->aggregate([
            [
                '$search' => [
                    'index' => 'default',
                    'text' => [
                        'query' => $searchTerm,
                        'path' => 'product_name'
                    ]
                ]
            ],
            [
                '$limit' => 10
            ]
        ])->toArray();

        // Verarbeiten Sie die Suchergebnisse und extrahieren Sie nur die Produkt-Namen
        $productNames = array_column($results, 'product_name');

        // Geben Sie die Produkt-Namen als JSON zurück
        echo json_encode($productNames);
    }
    wp_die();
    */
}

// Hängen Sie die AJAX-Aktion ab, um die Funktion zu deaktivieren
// remove_action('wp_ajax_search_with_atlas_search', 'search_with_atlas_search');
// remove_action('wp_ajax_nopriv_search_with_atlas_search', 'search_with_atlas_search');


?>
