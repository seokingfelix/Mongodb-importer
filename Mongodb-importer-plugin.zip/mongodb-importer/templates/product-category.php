<?php
/**
 * Das Template für die Anzeige von Produktkategorien.
 *
 * @package WordPress
 * @subpackage Ihr_Theme
 */

// Einbinden von Font Awesome
wp_enqueue_style( 'font-awesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css' );

// Einbinden des MongoDB-Clients
require_once dirname( __FILE__ ) . '/../../mongodb-importer/vendor/autoload.php';
use MongoDB\Client;


get_header();
?>


<head>
  <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" integrity="sha512-1lUfV6c5O9RyWSSof8CfjzqvMwSCZ81xRd7b8FjBz3qB3Q9CPiqjKzSsgvkrTbxTt/fnFt97FY4GjYvCMlJl4A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
  <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jqueryui-touch-punch/0.2.3/jquery.ui.touch-punch.min.js"></script>
</head>

	
<div class="Product-sidebar modal-filter">
    <?php include( plugin_dir_path( __FILE__ ) . '../../mongodb-importer/templates/filter.php' ); ?>

    <!-- Preis-Schieberegler initialisieren -->
    <script>
      // JavaScript-Code hier einfügen
      jQuery(document).ready(function() {
        var minPrice = <?php echo isset($_GET['min_price']) ? $_GET['min_price'] : '1'; ?>;
        var maxPrice = <?php echo isset($_GET['max_price']) ? $_GET['max_price'] : '10000'; ?>;

        // Initialisierung des Schiebereglers
        var slider = jQuery("#price-slider").slider({
          range: true,
          min: 1,
          max: 10000,
          values: [minPrice, maxPrice],
          create: function(event, ui) {
            var handles = jQuery(this).find(".ui-slider-handle");
            handles.eq(0).html('<i class="fas fa-circle-chevron-left slider-icon"></i>');
            handles.eq(1).html('<i class="fas fa-circle-chevron-right slider-icon"></i>');
          },
          slide: function(event, ui) {
            // Aktualisieren Sie die Eingabefelder mit den neuen Werten
            jQuery("#price-min").val(ui.values[0]);
            jQuery("#price-max").val(ui.values[1]);
          }
        });

        // Aktualisierung der Price-Min- und Price-Max-Felder
        jQuery("#price-min").val(slider.slider("values", 0));
        jQuery("#price-max").val(slider.slider("values", 1));

        // Wenn der Benutzer den min oder max Preis manuell eingibt, aktualisieren Sie den Schieberegler
        jQuery("#price-min, #price-max").on("change", function() {
          var minPrice = parseInt(jQuery("#price-min").val());
          var maxPrice = parseInt(jQuery("#price-max").val());
          slider.slider("values", [minPrice, maxPrice]);
        });
      });
    </script>
</div>

	
<div class="product-buttons">
  <button class="category-button">
    <span class="button-text">Kategorien</span>
    <i class="fa-solid fa-bars-staggered"></i>
  </button>
  <button class="filter-button" onclick="document.getElementById('filter-modal').style.display='block'">
    <span class="button-text">Filter</span>
    <i class="fa-solid fa-arrow-up-wide-short"></i>
  </button>
</div>



<!-- Modal-Box -->
<div id="filter-modal" class="modal">
  <div class="modal-content">
    <button class="close">&times;</button>
    <div class="Product-sidebar-mobile">
      <div class="filter-container">
        <p class="filter-title">Filter</p> <!-- Hier ist der hinzugefügte Text mit der CSS-Klasse "filter-title" -->
        <form>
          <ul class="myfilter">
            <?php
            if (isset($_GET['min_price']) && isset($_GET['max_price'])) {
                $minPrice = number_format((float)$_GET['min_price'], 2, ',', '.');
                $maxPrice = number_format((float)$_GET['max_price'], 2, ',', '.');
                echo '<li class="my-filter-price-range"><span class="remove-filter"><i class="fas fa-times"></i></span> ' . $minPrice . ' € - ' . $maxPrice . ' €</li>';
            }
            ?>
          </ul>
          <div id="price-slider"></div>
          <div class="price-inputs">
            <input type="text" id="price-min" name="min_price" value="" placeholder="min. Preis">
            <input type="text" id="price-max" name="max_price" value="" placeholder="max. Preis">
          </div>
          <button type="submit">Filter anwenden</button>
        </form>
      </div>
    </div>
  </div>
</div>




    <?php
    // Hier können Sie den Code hinzufügen, um Produkte aus der MongoDB-Datenbank abzurufen.
    $mongoDbUsername = 'zinkbusiness';
    $mongoDbPassword = 'hansuwe';
    $mongoDbConnectionString = 'mongodb+srv://zinkbusiness:hansuwe@Cluster1.bcc8n.mongodb.net/Shopniversum?retryWrites=true&w=majority';

try {
    $client = new MongoDB\Client($mongoDbConnectionString, [
        'username' => $mongoDbUsername,
        'password' => $mongoDbPassword
    ]);

    $databaseName = 'Shopniversum'; // Der Name Ihrer Datenbank
    $collectionName = 'Shopniversum-datafeeds'; // Der Name Ihrer Sammlung, in der die Produktinformationen gespeichert sind

    $collection = $client->selectCollection($databaseName, $collectionName);

	$query = []; // Diese Zeile hinzufügen


// Filterwerte abrufen
$minPrice = isset($_GET['min_price']) ? (float)$_GET['min_price'] : 0.0;
$maxPrice = isset($_GET['max_price']) ? (float)$_GET['max_price'] : INF;


// Überprüfen, ob aktualisierte Filterwerte vorhanden sind
if (isset($_GET['min_price']) && isset($_GET['max_price'])) {
    $minPrice = (float)$_GET['min_price'];
    $maxPrice = (float)$_GET['max_price'];

    // Hinzufügen der Preisfilter zur Abfrage
if (isset($minPrice) && isset($maxPrice)) {
    $query['search_price'] = ['$gte' => $minPrice, '$lte' => $maxPrice];
}
}
	
	
	
	
$category_slug = get_post_meta(get_the_ID(), 'produkt_titel', true); // Get the value of the custom field 'produkt_titel'

	
$documentsPerPage = 48; // Anzahl der Einträge pro Seite

$pg = isset($_GET['pg']) ? intval($_GET['pg']) : 1;

$skip = ($pg - 1) * $documentsPerPage; // Anzahl der zu überspringenden Dokumente

$pipeline = [
    [
        '$search' => [
            'compound' => [
                'must' => [
                    [
                        'text' => [
                            'query' => $category_slug,
                            'path' => 'product_name',
                            'fuzzy' => [
                                'maxEdits' => 2,
                                'prefixLength' => 3
                            ]
                        ]
                    ],
                    [
                        'range' => [
                            'path' => 'search_price',
                            'gte' => $minPrice,
                            'lte' => $maxPrice,
                        ]
                    ]
                ],
            ],
            'index' => 'default'
        ]
    ],
    [
        '$skip' => $skip
    ],
    [
        '$limit' => $documentsPerPage
    ],
    [
        '$project' => [
            'aw_deep_link' => 1,
            'aw_image_url' => 1,
            'product_name' => 1,
            'description' => 1,
            'search_price' => 1,
            'merchant_name' => 1,
            'delivery_cost' => 1,
            'score' => ['$meta' => 'searchScore']
        ]
    ]
];


// Ausführen der Aggregationspipeline
$cursor = $collection->aggregate($pipeline);

// Zählen der Anzahl der Produkte, die den Filterkriterien entsprechen
$countPipeline = [
    [
        '$search' => [
            'compound' => [
                'must' => [
                    [
                        'text' => [
                            'query' => $category_slug,
                            'path' => 'product_name',
                            'fuzzy' => [
                                'maxEdits' => 2,
                                'prefixLength' => 3
                            ]
                        ]
                    ],
                    [
                        'range' => [
                            'path' => 'search_price',
                            'gte' => $minPrice,
                            'lte' => $maxPrice,
                        ]
                    ]
                ],
            ],
            'index' => 'default'
        ]
    ],
    [
        '$count' => 'count'
    ]
];

$countResult = $collection->aggregate($countPipeline)->toArray();
$count = isset($countResult[0]['count']) ? $countResult[0]['count'] : 0;

// Anzahl der Seiten
$totalPages = ceil($count / $documentsPerPage);





echo '<div class="search_result">';
echo '<div class="search_result_container">';

echo '<div class="search-results-header">';
echo '<div class="search-results-head-title-container">';
echo '<h1 class="search-result-head-title">' . get_the_title() . '</h1>';

// Ausgabe der Anzahl der Produkte, die den Filterkriterien entsprechen
echo '<small class="search-result-head_results">' . $count . ' Ergebnisse gefunden</small>';

echo '</div>';
echo '</div>';

echo '<div class="product-list">';
foreach ($cursor as $document) {
    echo '<div class="product-box">';
    echo '<div class="product_box_inlay_border">';
    echo '<a href="' . $document['aw_deep_link'] . '" target="_blank" class="product col-6">';
    echo '<div class="product-image-container">';
    echo '<img class="product-image" src="' . $document['aw_image_url'] . '" alt="' . $document['product_name'] . '" style="max-width: 100%;">';
    echo '</div>'; // Schließtag für "product-image-container"
    echo '<div class="product-box-text-container">';
    echo '<div class="product-name"><span class="product-title">' . $document['product_name'] . '</span></div>';
    echo '<div class="product-description">' . substr($document['description'], 0, 150) . '...</div>';
    echo '</div>'; // Schließtag für "product-box-text-container"
    echo '<p class="product-price">' . number_format($document['search_price'], 2) . ' <span class="currency">&euro;</span></p>';
    echo '<div class="product-merchant">' . $document['merchant_name'] . '</div>';
    echo '<div class="product-delivery-cost">Versand: ' . number_format($document['delivery_cost'], 2) . ' <span class="currency">&euro;</span></div>'; // Zeile hinzugefügt für Versandkosten

    echo '<div class="button-group">';
    echo '<button class="product-link" onclick="window.open(\'' . $document['aw_deep_link'] . '\',\'_blank\')">zum Shop »</button>';
    echo '</div>'; // Schließtag für "button-group"
    echo '</a>'; // Schließtag für "product col-6"
    echo '</div>'; // Schließtag für "product_box_inlay_border"
    echo '</div>'; // Schließtag für "product-box"
}
echo '</div>'; // Schließtag für "product-list"


// Pagination-Container außerhalb des search_result_container platzieren
echo '<div class="pagination-container">';

// Anfangs- und Endseite der Seitenzahl-Begrenzung
$visiblePages = 5; // Anzahl der angezeigten Seitenzahlen
$startPage = max(1, $pg - floor($visiblePages / 2));
$endPage = min($totalPages, $startPage + $visiblePages - 1);
$startPage = max(1, $endPage - $visiblePages + 1);

		
// Überprüfen, ob die Pagination auf einem mobilen Gerät angezeigt wird
$isMobile = wp_is_mobile();
if ($isMobile) {
    // Anzahl der angezeigten Seitenzahlen auf 1 reduzieren
    $startPage = max(1, $pg - 1);
    $endPage = min($totalPages, $pg + 1);
}

if ($pg < $totalPages) {
    echo '<a href="?pg='.($pg + 1).'" class="next-page-button">Nächste Seite</a>';
}

		echo '<div class="pagination-inner-container">';

// Vorherige Seite
if ($pg > 1) {
    echo '<a href="?pg='.($pg - 1).'" class="pagination-link"><i class="fas fa-chevron-left"></i></a>';
}



// Seitenzahlen
if ($startPage > 1) {
    echo '<a href="?pg=1" class="pagination-link">1</a> '; // Immer die erste Seite anzeigen
    if ($startPage > 2) {
        echo '<span class="pagination-dots">...</span>'; // Punkte vor den Seitenzahlen anzeigen
    }
}

for ($i = $startPage; $i <= $endPage; $i++) {
    if ($i == $pg) {
        echo '<a href="?pg='.$i.'" class="pagination-link active">'.$i.'</a> ';
    } else {
        echo '<a href="?pg='.$i.'" class="pagination-link">'.$i.'</a> ';
    }
}

if ($endPage < $totalPages) {
    if ($endPage < $totalPages - 1) {
        echo '<span class="pagination-dots">...</span>'; // Punkte nach den Seitenzahlen anzeigen
    }
    echo '<a href="?pg='.$totalPages.'" class="pagination-link">'.$totalPages.'</a>'; // Immer die letzte Seite anzeigen
}

// Nächste Seite
if ($pg < $totalPages) {
    echo '<a href="?pg='.($pg + 1).'" class="pagination-link"><i class="fas fa-chevron-right"></i></a>';
}





echo '</div>'; // Schließtag für "pagination-inner-container"
echo '</div>'; // Schließtag für "pagination-container"
echo '</div>'; // Schließtag für "search_result_container"
echo '</div>'; // Schließtag für "search_result"

        echo '</div>';

    } catch (Exception $e) {
        echo 'Verbindung zur MongoDB fehlgeschlagen: ', $e->getMessage(), "\n";
    }

// Fügen Sie den Blog-Inhalt hier ein
if ( have_posts() ) {
    echo '<div class="blog-container">'; // Öffnen des Container-Divs
    while ( have_posts() ) {
        the_post(); 
        the_content();
    }
    echo '</div>'; // Schließen des Container-Divs
}


get_footer();
?>

<script>
document.addEventListener("DOMContentLoaded", function() {
  var filterButton = document.querySelector('.filter-button');
  var modal = document.getElementById('filter-modal');

  filterButton.addEventListener('click', function(event) {
    event.stopPropagation();
    modal.style.display = 'block';
    modal.classList.add('show');
  });

  var closeButton = document.querySelector("#filter-modal .close");

closeButton.addEventListener('click', function(event) {
    event.stopPropagation();
    closeModal();
});

  modal.addEventListener('click', function(event) {
    if (event.target == modal) {
      closeModal();
    }
  });

  document.addEventListener('click', function(event) {
    if (!event.target.closest('.modal-content') && modal.classList.contains('show')) {
      closeModal();
    }
  });
});

// Filter-Modal-Box schließen
function closeModal() {
  var modal = document.getElementById('filter-modal');
  modal.classList.remove('show'); // Remove the 'show' class
  modal.classList.add('close-animation');
  setTimeout(function() {
    modal.style.display = 'none';
    modal.classList.remove('close-animation');
  }, 500); // Wait until the animation is complete before hiding the modal
}



// Klicken Sie außerhalb des Modals, um es zu schließen
window.onclick = function(event) {
  if (event.target == document.getElementById('filter-modal')) {
    closeModal();
  }
};

jQuery(document).ready(function() {
  // Click-Handler für das Entfernen des Filters
  jQuery(".my-filter-price-range").click(function() {
    // Aktualisieren der Seite und Entfernen der min_price und max_price Parameter
    var url = window.location.href;
    var updatedUrl = url.replace(/\?min_price=.*&max_price=.*/, '');
    window.location.href = updatedUrl;
  });
});




</script>
