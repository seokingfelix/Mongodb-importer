<?php
/**
 * Filter für Produktkategorien.
 *
 * @package WordPress
 * @subpackage Ihr_Theme
 */
?>

<head>
	<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

	<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" integrity="sha512-1lUfV6c5O9RyWSSof8CfjzqvMwSCZ81xRd7b8FjBz3qB3Q9CPiqjKzSsgvkrTbxTt/fnFt97FY4GjYvCMlJl4A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
	<link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
</head>

<div class="search-sidebar-selectbox-title">
    <?php echo get_the_title(); ?>
</div>

<div class="Product-sidebar">
  <div class="filter-container">
    <ul class="myfilter">
      <?php
      if (isset($_GET['min_price']) && isset($_GET['max_price'])) {
          $minPrice = number_format((float)$_GET['min_price'], 2, ',', '.');
          $maxPrice = number_format((float)$_GET['max_price'], 2, ',', '.');
          echo '<li class="my-filter-price-range"><span class="remove-filter"><i class="fas fa-times"></i></span> ' . $minPrice . ' € - ' . $maxPrice . ' €</li>';
      }
      ?>
    </ul>

    <form class="price-slider-form">
      <div id="price-slider"></div>

      <div class="price-inputs">
        <input type="text" id="price-min" name="min_price" value="" placeholder="min. Preis">
        <input type="text" id="price-max" name="max_price" value="" placeholder="max. Preis">
      </div>
<button type="submit" class="price-filter-button">Filter anwenden</button>
    </form>
  </div>
</div>

<div class="material-container">
  <input type="text" id="material-search" placeholder="Material suchen...">
  <div class="material-list">
    <ul>
      <?php
      // Array mit Materialien
      $materials = array('Holz', 'Stahl', 'Glas', 'Plastik', 'Keramik', 'Leder');

      foreach ($materials as $material) {
        echo "<li class='material-item'>$material</li>";
      }
      ?>
    </ul>
  </div>
</div>

<script>
  // JavaScript-Code hier einfügen
  jQuery(document).ready(function() {
    var minPrice = <?php echo isset($_GET['min_price']) ? $_GET['min_price'] : '1'; ?>;
    var maxPrice = <?php echo isset($_GET['max_price']) ? $_GET['max_price'] : '10000'; ?>;

    // Initialisierung des Schiebereglers
    var slider = jQuery("#price-slider").slider({
      range: true,
      min: 1,
      max: 10000,
      values: [minPrice, maxPrice],
      create: function(event, ui) {
        var handles = jQuery(this).find(".ui-slider-handle");
        handles.eq(0).html('<i class="fas fa-circle-chevron-left slider-icon"></i>');
        handles.eq(1).html('<i class="fas fa-circle-chevron-right slider-icon"></i>');
      },
      slide: function(event, ui) {
        // Aktualisieren Sie die Eingabefelder mit den neuen Werten
        jQuery("#price-min").val(ui.values[0]);
        jQuery("#price-max").val(ui.values[1]);
      }
    });

    // Aktualisierung der Price-Min- und Price-Max-Felder
    jQuery("#price-min").val(slider.slider("values", 0));
    jQuery("#price-max").val(slider.slider("values", 1));

  // Wenn der Benutzer den min oder max Preis manuell eingibt, aktualisieren Sie den Schieberegler
  jQuery("#price-min, #price-max").on("change", function() {
    var minPrice = parseInt(jQuery("#price-min").val());
    var maxPrice = parseInt(jQuery("#price-max").val());
    slider.slider("values", [minPrice, maxPrice]);
  });
});


  jQuery(document).ready(function() {
    jQuery("#material-search").on("keyup", function() {
      var value = jQuery(this).val().toLowerCase();
      jQuery(".material-item").filter(function() {
        jQuery(this).toggle(jQuery(this).text().toLowerCase().indexOf(value) > -1);
      });
    });
  });
</script>

<style>
  .material-container {
    margin-top: 20px;
  }

  .material-list {
    height: 200px; /* Höhe der scrollbaren Liste */
    overflow-y: auto; /* scrollbar anzeigen, wenn Inhalt die Höhe übersteigt */
  }
</style>