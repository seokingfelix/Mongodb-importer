function myplugin_enqueue_scripts() {
    wp_enqueue_script('jquery-ui', 'https://code.jquery.com/ui/1.12.1/jquery-ui.min.js', array('jquery'));
    wp_enqueue_script('jquery', 'https://code.jquery.com/jquery-3.6.0.min.js');
}

add_action('wp_enqueue_scripts', 'myplugin_enqueue_scripts');

