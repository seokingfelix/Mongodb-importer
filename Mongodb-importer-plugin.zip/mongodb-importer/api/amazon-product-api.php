<?php
require 'vendor/autoload.php';

// Importieren der benötigten Klassen aus der Amazon Product Advertising API
use AmazonProductAdvertisingAPI\v1\com\amazon\paapi5\v1\api\DefaultApi;
use AmazonProductAdvertisingAPI\v1\com\amazon\paapi5\v1\PartnerType;
use AmazonProductAdvertisingAPI\v1\com\amazon\paapi5\v1\Configuration;
use AmazonProductAdvertisingAPI\v1\com\amazon\paapi5\v1\SearchItemsRequest;
use AmazonProductAdvertisingAPI\v1\com\amazon\paapi5\v1\SearchItemsResource;

function searchAmazonProducts($keywords) {
    $config = new Configuration();
    $config->setAccessKey('AKIAJO2SZY2QPCDFRYUQ');
    $config->setSecretKey('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');
    $config->setHost('webservices.amazon.de');
    $config->setRegion('eu-west-1');

    $apiInstance = new DefaultApi(
        new GuzzleHttp\Client(),
        $config
    );

    $searchItemsRequest = new SearchItemsRequest();
    $searchItemsRequest->setPartnerTag('supermoebel-21');
    $searchItemsRequest->setPartnerType(PartnerType::ASSOCIATES);
    $searchItemsRequest->setKeywords($keywords);
    $searchItemsRequest->setResources([
        SearchItemsResource::ITEM_INFOTITLE,
        SearchItemsResource::ITEM_INFOLIST_PRICE
    ]);

    try {
        $searchItemsResponse = $apiInstance->searchItems($searchItemsRequest);
        $items = $searchItemsResponse->getSearchResult()->getItems();
        return $items;
    } catch (Exception $e) {
        echo 'Exception when calling DefaultApi->searchItems: ', $e->getMessage(), PHP_EOL;
    }
}

// Den Namen des Produkts aus der URL extrahieren
$category_slug = basename(get_permalink());

// Suchen Sie die Produkte, die den extrahierten Namen enthalten
$items = searchAmazonProducts($category_slug);

// Die Anzahl der gefundenen Produkte
$countResult = count($items);

// Beginnen Sie mit der Ausgabe der Produkte in HTML
echo '<div class="search_result">';
echo '<div class="search_result_container">';

echo '<div class="search-results-header">';
echo '<div class="search-results-head-title-container">';
echo '<h1 class="search-result-head-title">' . get_the_title() . '</h1>';

// Ausgabe der Anzahl der Produkte, die den Filterkriterien entsprechen
echo '<small class="search-result-head_results">' . $countResult . ' Ergebnisse gefunden</small>';

echo '</div>';
echo '</div>';

echo '<div class="product-list">';
foreach ($items as $item) {
    $itemInfo = $item->getItemInfo();
    $title = $itemInfo->getTitle()->getDisplayValue();
    $price = $itemInfo->getListPrice()->getAmount();
    $imageUrl = $item->getImages()->getPrimary()->getLarge()->getURL();
    $link = $item->getDetailPageURL();

    echo '<div class="product-box">';
    echo '<div class="product_box_inlay_border">';
    echo '<a href="' . $link . '" target="_blank" class="product col-6">';
    echo '<div class="product-image-container">';
    echo '<img class="product-image" src="' . $imageUrl . '" alt="' . $title . '" style="max-width: 100%;">';
    echo '</div>'; // Schließtag für "product-image-container"
    echo '<div class="product-box-text-container">';
    echo '<div class="product-name"><span class="product-title">' . $title . '</span></div>';
    echo '</div>'; // Schließtag für "product-box-text-container"
    echo '<p class="product-price">' . number_format($price, 2) . ' <span class="currency">&euro;</span></p>';
    echo '<div class="button-group">';
    echo '<button class="product-link" onclick="window.open(\'' . $link . '\',\'_blank\')">zum Shop »</button>';
    echo '</div>'; // Schließtag für "button-group"
    echo '</a>'; // Schließtag für "product col-6"
    echo '</div>'; // Schließtag für "product_box_inlay_border"
    echo '</div>'; // Schließtag für "product-box"
}
// ...

echo '</div>'; // Schließtag für "search_result_container"
echo '</div>'; // Schließtag für "search_result"