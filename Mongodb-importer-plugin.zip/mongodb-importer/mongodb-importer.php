<?php
/**
 * Plugin Name: MongoDB Importer
 * Plugin URI: https://example.com/mongodb-importer
 * Description: Importiert WooCommerce-Produkte aus einer MongoDB-Datenbank
 * Version: 1.0.0
 * Author: Ihr Name
 * Author URI: https://example.com/
 * License: GPL-3.0-or-later
 * Text Domain: mongodb-importer
 */

require_once __DIR__ . '/vendor/autoload.php'; 

use MongoDB\Client;

function get_mongodb_client() {
    $mongoDbUsername = 'zinkbusiness';
    $mongoDbPassword = 'fOztczYUwNGQZLSv';
    $mongoDbConnectionString = 'mongodb+srv://zinkbusiness:fOztczYUwNGQZLSv@atlasmoebelshop.dchml8q.mongodb.net/Moebelshop?retryWrites=true&w=majority';

    try {
        $client = new MongoDB\Client($mongoDbConnectionString, [
            'username' => $mongoDbUsername,
            'password' => $mongoDbPassword
        ]);
        return $client;
    } catch (Exception $e) {
        echo 'Verbindung zur MongoDB fehlgeschlagen: ', $e->getMessage(), "\n";
    }
}

function get_number_of_documents() {
    $client = get_mongodb_client();
    if ($client) {
        $collection = $client->selectCollection('Moebelshop', 'moebelshop-collection-data');
        $count = $collection->countDocuments();
        echo 'Anzahl der Dokumente: ' . $count;
    } else {
        echo 'Verbindung zur MongoDB fehlgeschlagen.';
    }
}

function get_all_documents() {
    $client = get_mongodb_client();
    if ($client) {
        $collection = $client->selectCollection('Moebelshop', 'moebelshop-collection-data');
        $cursor = $collection->find();
        foreach ($cursor as $document) {
            print_r($document);
        }
    } else {
        echo 'Verbindung zur MongoDB fehlgeschlagen.';
    }
}

function mongodb_importer_template_include($template)
{
    if (is_singular('produktseiten') && is_single()) {
        $new_template = plugin_dir_path(__FILE__) . 'templates/product-category.php';
        if (file_exists($new_template)) {
            return $new_template;
        }
    }

    return $template;
}
add_filter('template_include', 'mongodb_importer_template_include');





function test_mongodb_connection() {
    $client = get_mongodb_client();
    if ($client) {
        echo 'Verbindung zur MongoDB erfolgreich hergestellt.';
    } else {
        echo 'Verbindung zur MongoDB fehlgeschlagen.';
    }
}

function test_mongodb_connection_and_get_documents() {
    if (is_page('mongodb-test')) {
        test_mongodb_connection();
        get_number_of_documents();
    }
}

add_action('wp', 'test_mongodb_connection_and_get_documents');
?>